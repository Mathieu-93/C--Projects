using System;

namespace Homework
{
    public abstract class Car
    {
        protected string body;
        protected string tyre;
        protected string engine;
        public abstract string ShowParameters();
    }
}