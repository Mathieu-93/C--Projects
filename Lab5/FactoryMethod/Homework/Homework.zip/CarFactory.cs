using System;
using System.Collections.Generic;
using System.Text;

namespace Homework
{
    abstract class CarFactory
    {
        public abstract Car Create();
    }
}