using System;
using System.Collections.Generic;
using System.Text;

namespace homework4
{
    class ScientificProbe:ITool
    {
        public void Conserve(){
            Console.WriteLine("Scientific probe ready..");
        }
        public void GatherDate(){
        }
    }
}