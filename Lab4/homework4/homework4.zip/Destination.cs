using System;
using System.Collections.Generic;
using System.Text;

namespace homework4
{
    class Destination
    {
        public string Name{get;set;}
        public Destination(string name){
            this.Name = name;
        }
    }
}