using System;
using System.Collections.Generic;
using System.Text;

namespace homework4
{
    interface ITool
    {
        void Conserve(){}
    }
}