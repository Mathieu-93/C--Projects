using System;
using System.Collections.Generic;
using System.Text;

namespace homework4
{
    class Captain:Human
    {
        public Captain(double s):base(s){}
    }
}