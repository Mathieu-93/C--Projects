using System;
using System.Collections.Generic;
using System.Text;

namespace homework4
{
    class Crewmember:Human
    {
        public Crewmember(double s):base(s){}

    }
}