using System;

namespace GiftCreator
{
    interface IGiftOperation
    {
        void Show();
        int CalculateTotalPrice();
    }
}
