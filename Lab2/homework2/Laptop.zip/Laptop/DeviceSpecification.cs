using System;

namespace Laptop
{
    interface IDeviceSpecification
    {
        string Specification();
    }
    
}