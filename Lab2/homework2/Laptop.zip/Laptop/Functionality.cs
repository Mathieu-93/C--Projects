using System;

namespace Laptop
{
    interface IFunctionality
    {
        bool IsTurnOn{set;get;}
        void ConnectViaBle();

    }
    
}